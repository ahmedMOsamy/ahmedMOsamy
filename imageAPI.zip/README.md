# Image processing API

This project is part of the Udacity Full-Stack Javascript Nanodegree

# Scripts

- start : "nodemon src/index.ts"
- lint : "eslint src/\*_/_.ts"
- prettier : "prettier --write src/\*_/_.ts"
- build : "npx tsc"
- jasmine : "jasmine"
- test : "npm run build && npm run jasmine"

# devDependencies

- @types/express : "^4.17.13",
- @types/jasmine : "^4.0.3",
- @types/node : "^17.0.25",
- @types/sharp : "^0.30.2",
- @types/supertest : "^2.0.12",
- @typescript-eslint/eslint-plugin : "^5.20.0",
- @typescript-eslint/parser : "^5.20.0",
- eslint : "^8.13.0",
- eslint-config-prettier : "^8.5.0",
- eslint-plugin-prettier : "^4.0.0",
- eslint-plugin-react : "^7.29.4",
- jasmine : "^4.1.0",
- jasmine-spec-reporter : "^7.0.0",
- nodemon : "^2.0.15",
- prettier : "^2.6.2",
- supertest : "^6.2.2",
- ts-node : "^10.7.0",
- typescript : "^4.6.3",

# dependencies

- express : "^4.17.3",
- sharp : "^0.30.4",

# Usage

The server will listen on port 3000:

# homepage endpoint

http://localhost:3000/api

# Example 1

http://localhost:3000/api
will display:
Hello, its my new project with udacity, kindly add {/images?filename=name&width=number&height=number.} to the URL to review selected image.

# Example 2

http://localhost:3000/api/images?filename=fjord&width=200&height=200
Will scale the fjord image to 200 by 200 pixels and store the resulting image.
On subsequent calls will serve the resized image instead of resizing the
original again.

# Example 3

http://localhost:3000/api/images?filename=fjord&width=200&height=hello
will display:
invalid url (filename, width and height are mandatory also width and height must be numbers).

# Example 4

http://localhost:3000/api/images?filename=???&width=200&height=200
will display:
There is no such file on the server, please verify the file name.

# Notes

- Images are served from `images/full`. Further images with the extension
  can be put into that directory, but the filetype is not checked
  (not required in exercise).
- Image thumbs will be stored in `images/thumb` and can be deleted from
  there to verify that in that case they will be re-created on subsequent calls
  to the same endpoint.
