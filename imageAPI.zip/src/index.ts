import express from 'express';
import routes from './routes/index';

const app = express();
const port = 3000;

app.use('/api', routes);

app.get('/api', (_, res: express.Response): void => {
  res.send(
    'Hello, its my new project with udacity, kindly add {/images?filename=name&width=number&height=number.} to the URL to review selected image.'
  );
});

app.listen(port, () => {
  console.log(`Server started at http://localhost:${port}/api`);
});

export default app;
