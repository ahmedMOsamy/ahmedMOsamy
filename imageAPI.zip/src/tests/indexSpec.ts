import supertest from 'supertest';
import fs from 'fs';
import path from 'path';
import app from '../index';
import imgResize from '../utilities/imgResize';

const request = supertest(app);

describe('Test endpoint response', () => {
  it('gets the api/images endpoint ', async () => {
    const response = await request.get('/api');
    expect(response.status).toBe(200);
  });
});
describe('Test image processing', () => {
  const filename = 'fjord';
  const width = 400;
  const height = 400;
  const outputPath: string =
    path.join(__dirname, '../', '../', 'images/', 'thumb/', filename) + `-${width}-${height}.jpg`;

  it('resizes an image when proper parameters are set in the url', async () => {
    await request.get(`/api/images?filename=${filename}&width=${width}&height=${height}`);
    expect(fs.existsSync(outputPath)).toBeTrue();
  });

  it('returns warning message if the image to be processed does not exist', async () => {
    const response = await request.get(`/api/images?filename=test&width=${width}&height=${height}`);
    expect(response.text).toBe('There is no such file on the server, please verify the file name.');
  });

  it('returns warning message if one of the url parameters is not set', async () => {
    const response = await request.get(`/api/images?filename=${filename}&width=${width}`);
    expect(response.text).toBe(
      'invalid url (filename, width and height are mandatory also width and height must be numbers).'
    );
  });
  it('returns warning message if width or height are not numbers', async () => {
    const response = await request.get(`/api/images?filename=${filename}&width=${width}&height=test`);
    expect(response.text).toBe(
      'invalid url (filename, width and height are mandatory also width and height must be numbers).'
    );
  });
  it('can be created correctly', async () => {
    expect(async () => await imgResize(filename, width, height)).not.toThrow();
  });
});
