import path from 'path';
import sharp from 'sharp';
import { promises as fsPromises } from 'fs';
import fs from 'fs';

const imgResize = async (filename: string, width: number, height: number): Promise<string> => {
  const inputPath: string = path.join(__dirname, '../', '../', 'images/', 'full/', filename) + '.jpg';
  const imageThumb: string = path.join(__dirname, '../', '../', 'images/', 'thumb/');
  const outputPath: string =
    path.join(__dirname, '../', '../', 'images/', 'thumb/', filename) + `-${width}-${height}.jpg`;

  if (!fs.existsSync(imageThumb)) {
    await fsPromises.mkdir(imageThumb);
  }
  try {
    await sharp(inputPath).resize(width, height).toFile(outputPath);
    return outputPath;
  } catch (error) {
    return error as string;
  }
};

export default imgResize;
