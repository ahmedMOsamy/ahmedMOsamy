const arrOfItems = (arr: unknown[], items: unknown[]): boolean => arr.every((item) => items.indexOf(item) !== -1);

const isArrOfNumbers = (arr: unknown[]): boolean => arr.every((item) => Number.isInteger(item));

interface IQuery {
  filename: string;
  width: number;
  height: number;
}
const imgParams = (query: IQuery): boolean => {
  const params: string[] = ['filename', 'width', 'height'];
  const paramsKeys: string[] = Object.keys(query);
  const widthHeightkeys: number[] = [Number(query.width), Number(query.height)];
  return arrOfItems(params, paramsKeys) && isArrOfNumbers(widthHeightkeys);
};

export { imgParams, IQuery };
