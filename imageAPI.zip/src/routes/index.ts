import express from 'express';
import fs from 'fs';
import path from 'path';
import imgResize from '../utilities/imgResize';
import { imgParams, IQuery } from '../utilities/imgParams';

const routes = express.Router();

routes.get('/images', async (req: express.Request, res: express.Response) => {
  if (imgParams(req.query as unknown as IQuery)) {
    const filename = req.query.filename as string;
    const width = Number(req.query.width);
    const height = Number(req.query.height);

    const imageInThumb: string =
      path.join(__dirname, '../', '../', 'imeges/', 'thumb/', filename) + `-${width}-${height}.jpg`;

    if (fs.existsSync(imageInThumb)) {
      res.sendFile(imageInThumb);
    } else {
      const imgProcessed = await imgResize(filename as string, width, height);

      if (!String(imgProcessed).includes('Error')) {
        res.sendFile(imgProcessed);
      } else {
        res.status(404).send('There is no such file on the server, please verify the file name.');
      }
    }
  } else {
    res
      .status(500)
      .send('invalid url (filename, width and height are mandatory also width and height must be numbers).');
  }
});

export default routes;
